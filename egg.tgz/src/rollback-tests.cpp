// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("rollback tests\n", stdout);
  return lionss_run_workload("rollback-tests");
}
