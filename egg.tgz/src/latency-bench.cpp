// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("latency bench\n", stdout);
  return lionss_run_workload("latency-bench");
}
