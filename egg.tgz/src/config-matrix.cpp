// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("config matrix\n", stdout);
  return lionss_run_workload("config-matrix");
}
