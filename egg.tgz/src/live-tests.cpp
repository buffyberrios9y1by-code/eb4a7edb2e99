// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("live tests"); }
int main(){
  announce();
  return lionss_run_workload("live-tests");
}
