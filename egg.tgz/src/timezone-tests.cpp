// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("timezone tests"); }
int main(){
  announce();
  return lionss_run_workload("timezone-tests");
}
