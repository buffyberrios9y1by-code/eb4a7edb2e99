# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(gcc-14 src/gcc-14.cpp)
set_property(TARGET gcc-14 PROPERTY CXX_STANDARD 11)
target_link_libraries(gcc-14 lionss pthread)

add_executable(contention-bench src/contention-bench.cpp)
set_property(TARGET contention-bench PROPERTY CXX_STANDARD 11)
target_link_libraries(contention-bench lionss pthread)

add_executable(locale-tests src/locale-tests.cpp)
set_property(TARGET locale-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(locale-tests lionss pthread)

add_executable(cycles-per-byte src/cycles-per-byte.cpp)
set_property(TARGET cycles-per-byte PROPERTY CXX_STANDARD 11)
target_link_libraries(cycles-per-byte lionss pthread)

add_executable(dependency-graph src/dependency-graph.cpp)
set_property(TARGET dependency-graph PROPERTY CXX_STANDARD 11)
target_link_libraries(dependency-graph lionss pthread)

add_executable(emscripten src/emscripten.cpp)
set_property(TARGET emscripten PROPERTY CXX_STANDARD 11)
target_link_libraries(emscripten lionss pthread)

add_executable(upgrade-tests src/upgrade-tests.cpp)
set_property(TARGET upgrade-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(upgrade-tests lionss pthread)

add_executable(compile-time-report src/compile-time-report.cpp)
set_property(TARGET compile-time-report PROPERTY CXX_STANDARD 11)
target_link_libraries(compile-time-report lionss pthread)

add_executable(build-timing src/build-timing.cpp)
set_property(TARGET build-timing PROPERTY CXX_STANDARD 11)
target_link_libraries(build-timing lionss pthread)

add_executable(misra-check src/misra-check.cpp)
set_property(TARGET misra-check PROPERTY CXX_STANDARD 11)
target_link_libraries(misra-check lionss pthread)

add_executable(concepts-check src/concepts-check.cpp)
set_property(TARGET concepts-check PROPERTY CXX_STANDARD 11)
target_link_libraries(concepts-check lionss pthread)

add_executable(serialization-tests src/serialization-tests.cpp)
set_property(TARGET serialization-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(serialization-tests lionss pthread)

add_executable(rollback-tests src/rollback-tests.cpp)
set_property(TARGET rollback-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(rollback-tests lionss pthread)

add_executable(advisory-sync src/advisory-sync.cpp)
set_property(TARGET advisory-sync PROPERTY CXX_STANDARD 11)
target_link_libraries(advisory-sync lionss pthread)

add_executable(live-tests src/live-tests.cpp)
set_property(TARGET live-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(live-tests lionss pthread)

add_executable(latency-bench src/latency-bench.cpp)
set_property(TARGET latency-bench PROPERTY CXX_STANDARD 11)
target_link_libraries(latency-bench lionss pthread)

add_executable(configure-minimal src/configure-minimal.cpp)
set_property(TARGET configure-minimal PROPERTY CXX_STANDARD 11)
target_link_libraries(configure-minimal lionss pthread)

add_executable(windows-x86 src/windows-x86.cpp)
set_property(TARGET windows-x86 PROPERTY CXX_STANDARD 11)
target_link_libraries(windows-x86 lionss pthread)

add_executable(warm-cache-bench src/warm-cache-bench.cpp)
set_property(TARGET warm-cache-bench PROPERTY CXX_STANDARD 11)
target_link_libraries(warm-cache-bench lionss pthread)

add_executable(crash-handler-test src/crash-handler-test.cpp)
set_property(TARGET crash-handler-test PROPERTY CXX_STANDARD 11)
target_link_libraries(crash-handler-test lionss pthread)

add_executable(canary-build src/canary-build.cpp)
set_property(TARGET canary-build PROPERTY CXX_STANDARD 11)
target_link_libraries(canary-build lionss pthread)

add_executable(gcc-latest src/gcc-latest.cpp)
set_property(TARGET gcc-latest PROPERTY CXX_STANDARD 11)
target_link_libraries(gcc-latest lionss pthread)

add_executable(valgrind-helgrind src/valgrind-helgrind.cpp)
set_property(TARGET valgrind-helgrind PROPERTY CXX_STANDARD 11)
target_link_libraries(valgrind-helgrind lionss pthread)

add_executable(split-dwarf src/split-dwarf.cpp)
set_property(TARGET split-dwarf PROPERTY CXX_STANDARD 11)
target_link_libraries(split-dwarf lionss pthread)

add_executable(config-matrix src/config-matrix.cpp)
set_property(TARGET config-matrix PROPERTY CXX_STANDARD 11)
target_link_libraries(config-matrix lionss pthread)

add_executable(perf-record src/perf-record.cpp)
set_property(TARGET perf-record PROPERTY CXX_STANDARD 11)
target_link_libraries(perf-record lionss pthread)

add_executable(timezone-tests src/timezone-tests.cpp)
set_property(TARGET timezone-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(timezone-tests lionss pthread)

add_executable(abi-stability src/abi-stability.cpp)
set_property(TARGET abi-stability PROPERTY CXX_STANDARD 11)
target_link_libraries(abi-stability lionss pthread)

add_executable(wheel-build src/wheel-build.cpp)
set_property(TARGET wheel-build PROPERTY CXX_STANDARD 11)
target_link_libraries(wheel-build lionss pthread)

add_executable(ilp32-build src/ilp32-build.cpp)
set_property(TARGET ilp32-build PROPERTY CXX_STANDARD 11)
target_link_libraries(ilp32-build lionss pthread)

